// npm install -g npm@latest
// npm audit fix --force
// $ rm -rf node_modules
// npm install -g npm@7.6.0
// expo doctor --fix-dependencies