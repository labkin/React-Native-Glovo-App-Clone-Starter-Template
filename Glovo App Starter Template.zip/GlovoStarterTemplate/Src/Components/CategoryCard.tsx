import { View,  StyleSheet } from 'react-native'
import React, {} from 'react'


const CategoryCard = () => {

    

  return (
    <View>
     
    </View>
  )
}

export default CategoryCard


