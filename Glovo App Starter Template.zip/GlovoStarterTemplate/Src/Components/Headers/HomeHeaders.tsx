import { View, Animated } from 'react-native'


const HomeHeaders = () => {


  return (
    <Animated.View>
        
    </Animated.View>
  )
}

export default HomeHeaders