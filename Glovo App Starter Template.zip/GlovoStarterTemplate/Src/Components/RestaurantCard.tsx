import { View } from 'react-native'
import React from 'react'


const RestaurantCard = () => {
  return (
    <View>
             
    </View>
  )
}

export default RestaurantCard


