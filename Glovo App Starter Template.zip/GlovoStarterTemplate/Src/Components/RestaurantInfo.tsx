import { View} from 'react-native'
import React from 'react'


const RestaurantInfo = () => {
  return (
    <>
        
    </>
  )
}

export default RestaurantInfo