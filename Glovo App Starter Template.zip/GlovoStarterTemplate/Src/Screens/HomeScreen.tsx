import { View } from 'react-native'
import React, {} from 'react'
import { RootStackScreenProps } from '../Navigation/RootNavigation'



const HomeScreen = ({navigation, route}:RootStackScreenProps<"home">) => {

    return (
        <View>
    
        </View>
    )

}

export default HomeScreen