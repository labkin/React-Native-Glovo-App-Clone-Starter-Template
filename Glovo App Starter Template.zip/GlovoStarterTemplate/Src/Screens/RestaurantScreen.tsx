import { View } from 'react-native'
import React, {} from 'react'
import { RootStackScreenProps } from '../Navigation/RootNavigation'


const RestaurantScreen = ({navigation, route}:RootStackScreenProps<"restaurantDisplay">) => {

   return (
    <View>

    </View>
   )
}

export default RestaurantScreen